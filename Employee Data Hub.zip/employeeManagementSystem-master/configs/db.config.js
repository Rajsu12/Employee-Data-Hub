

module.exports ={
  HOST : "localhost",
  USER : "root",
  PASSWORD : "apple@17",
  DB : "emp_db",
  dialect:"mysql",
}